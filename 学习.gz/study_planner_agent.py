"""
智能学习规划助手
Smart Study Planner Agent

基于长链推理的学习计划生成系统
功能：目标分析 → 计划生成 → 执行追踪 → 动态调整
"""

import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass, field

# ==================== 数据模型 ====================

@dataclass
class Subject:
    """科目"""
    name: str
    current_level: int  # 1-10
    target_level: int   # 1-10
    difficulty: str     # easy/medium/hard
    daily_time: int      # 每天投入时间(分钟)

@dataclass
class Task:
    """学习任务"""
    id: int
    subject: str
    content: str
    duration: int        # 分钟
    priority: int        # 1-5，5最高
    deadline: str
    status: str          # pending/in_progress/completed
    created_at: str = ""

@dataclass
class StudyPlan:
    """学习计划"""
    goal: str
    deadline: str
    total_days: int
    subjects: List[Subject]
    daily_tasks: List[Dict]  # 每天的任务安排
    estimated_progress: Dict[str, int]  # 预估进度

# ==================== 核心Agent逻辑 ====================

class StudyAnalysisAgent:
    """分析Agent - 理解用户目标和当前水平"""
    
    def __init__(self):
        self.llm = None  # 可以接入MiMo V2.5 API
    
    def analyze_goal(self, user_input: str) -> Dict:
        """分析用户输入，提取目标信息"""
        # 简化版：基于关键词解析
        # 实际可接入MiMo V2.5进行自然语言理解
        
        info = {
            "target": "",
            "subjects": [],
            "time_available": 0,  # 每天可用时间
            "deadline": ""
        }
        
        # 关键词识别
        keywords = {
            "数学": ["数学", "高数", "线代", "微积分"],
            "英语": ["英语", "四级", "六级", "雅思", "托福"],
            "物理": ["物理", "力学", "电磁学"],
            "化学": ["化学", "有机", "无机"],
            "编程": ["编程", "Python", "Java", "代码"]
        }
        
        for subject, words in keywords.items():
            for word in words:
                if word in user_input:
                    if subject not in info["subjects"]:
                        info["subjects"].append(subject)
        
        # 提取时间信息
        if "天" in user_input:
            import re
            days = re.findall(r'(\d+)天', user_input)
            if days:
                info["deadline"] = (datetime.now() + timedelta(int(days[0]))).strftime("%Y-%m-%d")
        
        return info


class PlanGenerationAgent:
    """规划Agent - 生成个性化学习计划"""
    
    def __init__(self):
        self.priority_rules = {
            "hard": 5,
            "medium": 3,
            "easy": 1
        }
    
    def calculate_days(self, deadline: str) -> int:
        """计算剩余天数"""
        end = datetime.strptime(deadline, "%Y-%m-%d")
        return (end - datetime.now()).days
    
    def calculate_priority(self, subject: Subject, days_left: int) -> int:
        """计算科目优先级"""
        level_gap = subject.target_level - subject.current_level
        
        if level_gap <= 0:
            return 1
        
        # 需要提升的幅度越大，优先级越高
        base_priority = min(level_gap * 2, 5)
        
        # 剩余时间越少，难度高的科目优先级提升
        if days_left < 7 and subject.difficulty == "hard":
            base_priority = 5
        
        return base_priority
    
    def distribute_time(self, subjects: List[Subject], days_left: int, 
                       daily_available: int) -> List[Subject]:
        """分配每天的学习时间"""
        total_level_gap = sum(s.target_level - s.current_level for s in subjects)
        
        if total_level_gap == 0:
            return subjects
        
        # 按提升需求比例分配时间
        for subj in subjects:
            gap = subj.target_level - subj.current_level
            ratio = gap / total_level_gap
            subj.daily_time = int(daily_available * ratio)
        
        # 确保时间分配合理（最少30分钟）
        total_assigned = sum(s.daily_time for s in subjects)
        if total_assigned < daily_available:
            # 剩余时间给最容易的科目
            for subj in sorted(subjects, key=lambda x: x.daily_time):
                if subj.daily_time < 30:
                    subj.daily_time = 30
                    break
        
        return subjects
    
    def generate_daily_tasks(self, subjects: List[Subject], 
                            days: int) -> List[Dict]:
        """生成每天的学习任务"""
        daily_plans = []
        
        for day in range(1, days + 1):
            date = (datetime.now() + timedelta(day)).strftime("%Y-%m-%d")
            day_tasks = []
            
            # 按优先级排序
            sorted_subjects = sorted(subjects, 
                key=lambda x: x.daily_time, reverse=True)
            
            remaining_time = sum(s.daily_time for s in sorted_subjects)
            
            for subj in sorted_subjects:
                if subj.daily_time <= 0:
                    continue
                
                # 生成具体任务
                tasks = self._generate_tasks_for_subject(
                    subj, subj.daily_time, day
                )
                day_tasks.extend(tasks)
            
            daily_plans.append({
                "day": day,
                "date": date,
                "tasks": day_tasks,
                "total_minutes": sum(t["duration"] for t in day_tasks)
            })
        
        return daily_plans
    
    def _generate_tasks_for_subject(self, subject: Subject, 
                                    minutes: int, day: int) -> List[Dict]:
        """为单个科目生成任务"""
        tasks = []
        
        # 任务模板
        templates = {
            "数学": ["看知识点视频({})", "做练习题({}道)", "整理错题({}题)", "复习公式({})"],
            "英语": ["背单词({}个)", "听力训练({})", "阅读练习({}篇)", "写作练习({})"],
            "物理": ["看概念视频({})", "推导公式({})", "做题({}道)", "整理模型({})"],
            "化学": ["背方程式({})", "做实验题({}道)", "整理知识点({})"],
            "编程": ["看教程({})", "写代码({}行)", "Debug练习({})", "做项目({})"]
        }
        
        template_list = templates.get(subject.name, ["学习({})"])
        time_per_task = minutes // len(template_list)
        
        for i, tmpl in enumerate(template_list):
            task_content = tmpl.format(time_per_task)
            tasks.append({
                "id": day * 100 + i,
                "subject": subject.name,
                "content": task_content,
                "duration": time_per_task,
                "priority": self.priority_rules.get(subject.difficulty, 3),
                "status": "pending"
            })
        
        return tasks


class TrackingAgent:
    """追踪Agent - 追踪执行情况并调整"""
    
    def __init__(self):
        self.completion_history = []
    
    def track_completion(self, task: Dict, completed: bool) -> Dict:
        """追踪任务完成情况"""
        record = {
            "task_id": task["id"],
            "completed": completed,
            "timestamp": datetime.now().isoformat(),
            "actual_duration": task.get("actual_duration", 0)
        }
        
        self.completion_history.append(record)
        return record
    
    def calculate_completion_rate(self) -> float:
        """计算完成率"""
        if not self.completion_history:
            return 0.0
        
        completed = sum(1 for r in self.completion_history if r["completed"])
        return completed / len(self.completion_history)
    
    def suggest_adjustment(self, subjects: List[Subject], 
                          completion_rate: float) -> Dict:
        """根据完成情况建议调整"""
        suggestions = {
            "time_adjustment": {},
            "priority_change": {},
            "encouragement": ""
        }
        
        # 分析每个科目的完成情况
        for subj in subjects:
            subj_records = [
                r for r in self.completion_history 
                if r["task_id"] // 100 == 1  # 简化逻辑
            ]
            
            if subj_records:
                rate = sum(1 for r in subj_records if r["completed"]) / len(subj_records)
                if rate < 0.5:
                    suggestions["time_adjustment"][subj.name] = "减少"
                elif rate > 0.9:
                    suggestions["time_adjustment"][subj.name] = "增加"
        
        # 整体鼓励
        if completion_rate >= 0.8:
            suggestions["encouragement"] = "表现很棒！继续保持这个节奏！"
        elif completion_rate >= 0.6:
            suggestions["encouragement"] = "不错的开始！继续加油！"
        else:
            suggestions["encouragement"] = "计划有些激进，我们来优化一下。"
        
        return suggestions


class DynamicAdjustmentAgent:
    """调整Agent - 动态优化计划"""
    
    def __init__(self):
        self.adjustment_count = 0
    
    def adjust_plan(self, original_plan: Dict, 
                   tracking_data: Dict) -> Dict:
        """根据追踪数据调整计划"""
        self.adjustment_count += 1
        
        # 简化版：基于完成率调整
        completion_rate = tracking_data.get("completion_rate", 1.0)
        
        if completion_rate < 0.7:
            # 完成率太低，减少每天任务量
            new_plan = original_plan.copy()
            new_plan["adjustment_note"] = f"第{self.adjustment_count}次调整：减少任务量，提高完成率"
            
            # 降低任务难度
            for day in new_plan.get("daily_tasks", []):
                for task in day.get("tasks", []):
                    task["duration"] = int(task["duration"] * 0.8)
        
        elif completion_rate > 0.9:
            # 完成率太高，可以增加挑战
            new_plan = original_plan.copy()
            new_plan["adjustment_note"] = f"第{self.adjustment_count}次调整：适当增加难度"
        else:
            new_plan = original_plan
        
        return new_plan


# ==================== 主Agent编排 ====================

class SmartStudyPlannerAgent:
    """
    智能学习规划助手 - 主Agent
    
    核心逻辑流：
    用户输入目标 → 分析Agent理解 → 规划Agent生成 → 追踪Agent监控 → 调整Agent优化
    """
    
    def __init__(self):
        self.analysis_agent = StudyAnalysisAgent()
        self.planning_agent = PlanGenerationAgent()
        self.tracking_agent = TrackingAgent()
        self.adjustment_agent = DynamicAdjustmentAgent()
        
        self.current_plan: Optional[StudyPlan] = None
        self.history = []
    
    def create_plan(self, user_input: str, 
                   subjects: List[Dict],
                   daily_available: int = 120) -> Dict:
        """
        创建学习计划
        
        Args:
            user_input: 用户输入的目标描述
            subjects: 科目信息列表
            daily_available: 每天可用时间(分钟)
        
        Returns:
            完整的学习计划
        """
        print("=" * 50)
        print("🎯 智能学习规划助手")
        print("=" * 50)
        
        # Step 1: 分析目标
        print("\n[Step 1/4] 分析目标...")
        goal_info = self.analysis_agent.analyze_goal(user_input)
        print(f"  → 识别目标: {goal_info}")
        
        # Step 2: 处理科目信息
        print("\n[Step 2/4] 处理科目信息...")
        subject_objects = []
        for s in subjects:
            subj = Subject(
                name=s["name"],
                current_level=s.get("current_level", 5),
                target_level=s.get("target_level", 8),
                difficulty=s.get("difficulty", "medium"),
                daily_time=0
            )
            subject_objects.append(subj)
        
        deadline = goal_info.get("deadline") or \
                   (datetime.now() + timedelta(30)).strftime("%Y-%m-%d")
        days_left = self.planning_agent.calculate_days(deadline)
        
        # Step 3: 生成计划
        print("\n[Step 3/4] 生成学习计划...")
        
        # 分配时间
        subject_objects = self.planning_agent.distribute_time(
            subject_objects, days_left, daily_available
        )
        
        # 计算优先级
        for subj in subject_objects:
            subj.priority = self.planning_agent.calculate_priority(
                subj, days_left
            )
        
        # 生成每日任务
        daily_tasks = self.planning_agent.generate_daily_tasks(
            subject_objects, days_left
        )
        
        # Step 4: 整理输出
        print("\n[Step 4/4] 整理计划...")
        
        result = {
            "plan_id": f"PLAN_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "created_at": datetime.now().isoformat(),
            "goal": user_input,
            "deadline": deadline,
            "total_days": days_left,
            "daily_available_minutes": daily_available,
            "subjects": [
                {
                    "name": s.name,
                    "current_level": s.current_level,
                    "target_level": s.target_level,
                    "daily_time": s.daily_time,
                    "priority": s.priority
                }
                for s in subject_objects
            ],
            "daily_tasks": daily_tasks[:7],  # 显示前7天
            "summary": self._generate_summary(subject_objects, days_left)
        }
        
        self.current_plan = result
        self.history.append(result)
        
        print("\n✅ 计划生成完成！")
        return result
    
    def _generate_summary(self, subjects: List[Subject], 
                         days: int) -> str:
        """生成计划摘要"""
        total_time = sum(s.daily_time for s in subjects)
        hardest = max(subjects, key=lambda x: x.priority)
        
        summary = f"""
📊 计划摘要
━━━━━━━━━━━━━━
• 总天数: {days}天
• 每天学习: {total_time}分钟
• 科目数: {len(subjects)}个
• 最高优先级: {hardest.name} (等级{hardest.current_level}→{hardest.target_level})
"""
        return summary
    
    def track_task(self, task_id: int, completed: bool, 
                   actual_duration: int = 0) -> Dict:
        """追踪任务完成"""
        task = self._find_task(task_id)
        if not task:
            return {"error": "任务不存在"}
        
        record = self.tracking_agent.track_completion(
            task, completed
        )
        record["actual_duration"] = actual_duration
        
        return {
            "status": "recorded",
            "completion_rate": self.tracking_agent.calculate_completion_rate()
        }
    
    def get_adjustment(self) -> Dict:
        """获取计划调整建议"""
        rate = self.tracking_agent.calculate_completion_rate()
        
        suggestions = self.tracking_agent.suggest_adjustment(
            [], rate  # 简化
        )
        
        adjusted_plan = self.adjustment_agent.adjust_plan(
            self.current_plan,
            {"completion_rate": rate}
        )
        
        return {
            "current_completion_rate": rate,
            "suggestions": suggestions,
            "adjusted_plan": adjusted_plan
        }
    
    def _find_task(self, task_id: int) -> Optional[Dict]:
        """查找任务"""
        if not self.current_plan:
            return None
        
        for day in self.current_plan.get("daily_tasks", []):
            for task in day.get("tasks", []):
                if task["id"] == task_id:
                    return task
        
        return None


# ==================== 使用示例 ====================

def main():
    """主函数 - 演示完整流程"""
    
    # 初始化Agent
    planner = SmartStudyPlannerAgent()
    
    # 用户输入
    user_input = "我想在30天内提升数学和英语，数学从5级提到8级，英语从3级提到6级"
    
    # 科目信息
    subjects = [
        {
            "name": "数学",
            "current_level": 5,
            "target_level": 8,
            "difficulty": "hard"  # 数学较难
        },
        {
            "name": "英语",
            "current_level": 3,
            "target_level": 6,
            "difficulty": "medium"
        }
    ]
    
    # 创建计划
    print("\n" + "=" * 50)
    print("🚀 创建学习计划")
    print("=" * 50 + "\n")
    
    plan = planner.create_plan(
        user_input=user_input,
        subjects=subjects,
        daily_available=120  # 每天2小时
    )
    
    # 打印计划
    print("\n" + plan["summary"])
    
    print("\n📅 前3天计划预览:")
    print("-" * 40)
    
    for day in plan["daily_tasks"][:3]:
        print(f"\n📆 Day {day['day']} - {day['date']}")
        print(f"   总时长: {day['total_minutes']}分钟")
        for task in day["tasks"]:
            print(f"   • [{task['subject']}] {task['content']} "
                  f"({task['duration']}分钟) ⭐{task['priority']}")
    
    # 模拟追踪
    print("\n\n" + "=" * 50)
    print("📊 模拟任务追踪")
    print("=" * 50)
    
    if plan["daily_tasks"]:
        first_task = plan["daily_tasks"][0]["tasks"][0]
        result = planner.track_task(
            first_task["id"], 
            completed=True,
            actual_duration=25
        )
        print(f"\n✅ 任务完成记录: {result}")
        
        # 获取调整建议
        adjustment = planner.get_adjustment()
        print(f"\n📈 当前完成率: {adjustment['current_completion_rate']*100:.0f}%")
        print(f"💡 建议: {adjustment['suggestions']['encouragement']}")
    
    return plan


if __name__ == "__main__":
    main()